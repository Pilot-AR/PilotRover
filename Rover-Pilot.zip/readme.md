# Rover Control v1.0

## 🛠 Instalación

```bash
chmod +x install.sh
./install.sh